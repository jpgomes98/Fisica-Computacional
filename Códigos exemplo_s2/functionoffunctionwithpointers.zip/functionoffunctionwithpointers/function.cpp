#include <cstdlib>
#include <iostream>
#include <cmath>

using namespace std;

// this is the function we want to integrate

float function(float x){

      float result=x*x; //actually the function

      
      return result;
      }
