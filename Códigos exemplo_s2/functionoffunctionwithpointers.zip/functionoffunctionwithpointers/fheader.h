// header for main

float integralrect(float (* function)(float), float xmin, float xmax, int npoints);
float function(float x);
